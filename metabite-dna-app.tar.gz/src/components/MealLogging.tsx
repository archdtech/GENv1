"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Plus, 
  Utensils, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  X,
  Target
} from "lucide-react";

interface MealItem {
  foodName: string;
  quantity: number;
  unit: string;
  calories?: number;
  protein?: number;
  carbs?: number;
  fat?: number;
  fiber?: number;
  sugar?: number;
  sodium?: number;
}

interface Meal {
  id: string;
  name: string;
  description?: string;
  mealType: string;
  loggedAt: string;
  items: MealItem[];
  feedback?: {
    dnaAlignment: string;
    feedback: string;
    suggestions: string;
    score: number;
  };
}

interface MealLoggingProps {
  userId: string;
  onMealLogged?: (meal: Meal) => void;
}

const commonFoods = [
  { name: "Chicken Breast", calories: 165, protein: 31, carbs: 0, fat: 3.6, fiber: 0, sugar: 0 },
  { name: "Brown Rice", calories: 216, protein: 5, carbs: 45, fat: 1.8, fiber: 3.5, sugar: 0.7 },
  { name: "Broccoli", calories: 55, protein: 3.7, carbs: 11, fat: 0.6, fiber: 5.1, sugar: 1.5 },
  { name: "Salmon", calories: 208, protein: 20, carbs: 0, fat: 13, fiber: 0, sugar: 0 },
  { name: "Sweet Potato", calories: 86, protein: 1.6, carbs: 20, fat: 0.1, fiber: 3, sugar: 4.2 },
  { name: "Greek Yogurt", calories: 100, protein: 10, carbs: 6, fat: 4, fiber: 0, sugar: 6 },
  { name: "Almonds", calories: 579, protein: 21, carbs: 22, fat: 50, fiber: 12, sugar: 4 },
  { name: "Spinach", calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4, fiber: 2.2, sugar: 0.4 },
];

const units = ["g", "oz", "cup", "tbsp", "tsp", "piece", "medium", "large"];

export default function MealLogging({ userId, onMealLogged }: MealLoggingProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [logging, setLogging] = useState(false);
  const [mealName, setMealName] = useState("");
  const [mealDescription, setMealDescription] = useState("");
  const [mealType, setMealType] = useState("");
  const [items, setItems] = useState<MealItem[]>([{ 
    foodName: "", 
    quantity: 100, 
    unit: "g" 
  }]);
  const [status, setStatus] = useState<'idle' | 'logging' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState("");

  const addItem = () => {
    setItems([...items, { foodName: "", quantity: 100, unit: "g" }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    }
  };

  const updateItem = (index: number, field: keyof MealItem, value: any) => {
    const updatedItems = [...items];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    setItems(updatedItems);
  };

  const selectCommonFood = (index: number, food: typeof commonFoods[0]) => {
    const updatedItems = [...items];
    updatedItems[index] = {
      ...updatedItems[index],
      foodName: food.name,
      calories: food.calories,
      protein: food.protein,
      carbs: food.carbs,
      fat: food.fat,
      fiber: food.fiber,
      sugar: food.sugar,
    };
    setItems(updatedItems);
  };

  const logMeal = async () => {
    if (!mealName || !mealType || items.some(item => !item.foodName)) {
      setStatus('error');
      setMessage('Please fill in all required fields');
      return;
    }

    setLogging(true);
    setStatus('logging');

    try {
      const response = await fetch('/api/meals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          name: mealName,
          description: mealDescription,
          mealType,
          items,
        }),
      });

      const result = await response.json();

      if (result.success) {
        setStatus('success');
        setMessage('Meal logged successfully!');
        
        if (onMealLogged) {
          onMealLogged(result.meal);
        }

        // Reset form
        setMealName("");
        setMealDescription("");
        setMealType("");
        setItems([{ foodName: "", quantity: 100, unit: "g" }]);
        
        // Close dialog after success
        setTimeout(() => setIsOpen(false), 1500);
      } else {
        setStatus('error');
        setMessage(result.error || 'Failed to log meal');
      }
    } catch (error) {
      setStatus('error');
      setMessage('Network error while logging meal');
    } finally {
      setLogging(false);
    }
  };

  const getAlignmentBadge = (alignment: string) => {
    switch (alignment) {
      case 'aligned': return 'default';
      case 'moderate': return 'secondary';
      case 'misaligned': return 'destructive';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-4">
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Log Meal
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Log Your Meal</DialogTitle>
            <DialogDescription>
              Track what you eat and get DNA-powered feedback
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Status Messages */}
            {status === 'success' && (
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            )}
            {status === 'error' && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{message}</AlertDescription>
              </Alert>
            )}

            {/* Meal Details */}
            <div className="space-y-3">
              <div>
                <Label htmlFor="mealName">Meal Name *</Label>
                <Input
                  id="mealName"
                  value={mealName}
                  onChange={(e) => setMealName(e.target.value)}
                  placeholder="e.g., Grilled Chicken Salad"
                />
              </div>

              <div>
                <Label htmlFor="mealDescription">Description (Optional)</Label>
                <Textarea
                  id="mealDescription"
                  value={mealDescription}
                  onChange={(e) => setMealDescription(e.target.value)}
                  placeholder="Add any notes about your meal..."
                />
              </div>

              <div>
                <Label htmlFor="mealType">Meal Type *</Label>
                <Select value={mealType} onValueChange={setMealType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select meal type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="breakfast">Breakfast</SelectItem>
                    <SelectItem value="lunch">Lunch</SelectItem>
                    <SelectItem value="dinner">Dinner</SelectItem>
                    <SelectItem value="snack">Snack</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Food Items */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Food Items *</Label>
                <Button variant="outline" size="sm" onClick={addItem}>
                  <Plus className="h-4 w-4 mr-1" />
                  Add Item
                </Button>
              </div>

              {items.map((item, index) => (
                <Card key={index} className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">Item {index + 1}</Label>
                      {items.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeItem(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid gap-2">
                      <div>
                        <Label className="text-xs">Food Name</Label>
                        <Input
                          value={item.foodName}
                          onChange={(e) => updateItem(index, 'foodName', e.target.value)}
                          placeholder="e.g., Chicken Breast"
                        />
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <Label className="text-xs">Quantity</Label>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateItem(index, 'quantity', parseFloat(e.target.value) || 0)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Unit</Label>
                          <Select 
                            value={item.unit} 
                            onValueChange={(value) => updateItem(index, 'unit', value)}
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {units.map(unit => (
                                <SelectItem key={unit} value={unit}>{unit}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="text-xs">Calories</Label>
                          <Input
                            type="number"
                            value={item.calories || ''}
                            onChange={(e) => updateItem(index, 'calories', parseFloat(e.target.value) || undefined)}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-2">
                        <div>
                          <Label className="text-xs">Protein (g)</Label>
                          <Input
                            type="number"
                            value={item.protein || ''}
                            onChange={(e) => updateItem(index, 'protein', parseFloat(e.target.value) || undefined)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Carbs (g)</Label>
                          <Input
                            type="number"
                            value={item.carbs || ''}
                            onChange={(e) => updateItem(index, 'carbs', parseFloat(e.target.value) || undefined)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Fat (g)</Label>
                          <Input
                            type="number"
                            value={item.fat || ''}
                            onChange={(e) => updateItem(index, 'fat', parseFloat(e.target.value) || undefined)}
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Fiber (g)</Label>
                          <Input
                            type="number"
                            value={item.fiber || ''}
                            onChange={(e) => updateItem(index, 'fiber', parseFloat(e.target.value) || undefined)}
                          />
                        </div>
                      </div>

                      {/* Common Foods */}
                      <div>
                        <Label className="text-xs">Quick Select Common Foods</Label>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {commonFoods.slice(0, 4).map(food => (
                            <Button
                              key={food.name}
                              variant="outline"
                              size="sm"
                              onClick={() => selectCommonFood(index, food)}
                              className="text-xs"
                            >
                              {food.name}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Submit Button */}
            <Button 
              onClick={logMeal} 
              disabled={logging || status === 'success'}
              className="w-full"
            >
              {logging ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Logging Meal...
                </>
              ) : (
                <>
                  <Utensils className="h-4 w-4 mr-2" />
                  Log Meal
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}