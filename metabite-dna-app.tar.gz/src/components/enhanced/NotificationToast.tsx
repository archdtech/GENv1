"use client";

import { useEffect, useState } from "react";
import { useNotifications } from "@/contexts/NotificationContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, CheckCircle, AlertTriangle, Info, Award, Bell } from "lucide-react";

export default function NotificationToast() {
  const { notifications, markAsRead, removeNotification } = useNotifications();
  const [visibleNotifications, setVisibleNotifications] = useState<string[]>([]);

  useEffect(() => {
    // Show new notifications
    const newNotifications = notifications.filter(n => !n.read && !visibleNotifications.includes(n.id));
    
    newNotifications.forEach(notification => {
      setVisibleNotifications(prev => [...prev, notification.id]);
      
      // Auto-hide after 5 seconds for non-persistent notifications
      if (!notification.persistent) {
        setTimeout(() => {
          setVisibleNotifications(prev => prev.filter(id => id !== notification.id));
          markAsRead(notification.id);
        }, 5000);
      }
    });

    // Clean up old notifications
    const oldNotifications = visibleNotifications.filter(id => 
      !notifications.some(n => n.id === id)
    );
    if (oldNotifications.length > 0) {
      setVisibleNotifications(prev => prev.filter(id => !oldNotifications.includes(id)));
    }
  }, [notifications, visibleNotifications, markAsRead]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'achievement':
        return <Award className="h-5 w-5 text-purple-500" />;
      case 'error':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'info':
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'border-green-200 bg-green-50';
      case 'warning':
        return 'border-yellow-200 bg-yellow-50';
      case 'achievement':
        return 'border-purple-200 bg-purple-50';
      case 'error':
        return 'border-red-200 bg-red-50';
      case 'info':
      default:
        return 'border-blue-200 bg-blue-50';
    }
  };

  const toastsToShow = notifications
    .filter(n => visibleNotifications.includes(n.id))
    .slice(0, 3); // Show max 3 toasts at once

  if (toastsToShow.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 max-w-sm">
      {toastsToShow.map((notification) => (
        <Card
          key={notification.id}
          className={`${getNotificationColor(notification.type)} border shadow-lg transform transition-all duration-300 hover:scale-105`}
        >
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-0.5">
                {getNotificationIcon(notification.type)}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-gray-900">
                      {notification.title}
                    </h4>
                    <p className="text-sm text-gray-700 mt-1">
                      {notification.message}
                    </p>
                    
                    {notification.action && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2 h-7 text-xs"
                        onClick={notification.action.onClick}
                      >
                        {notification.action.label}
                      </Button>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-1 ml-2">
                    <button
                      onClick={() => {
                        markAsRead(notification.id);
                        setVisibleNotifications(prev => prev.filter(id => id !== notification.id));
                      }}
                      className="text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      <CheckCircle className="h-3 w-3" />
                    </button>
                    
                    <button
                      onClick={() => {
                        removeNotification(notification.id);
                        setVisibleNotifications(prev => prev.filter(id => id !== notification.id));
                      }}
                      className="text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}