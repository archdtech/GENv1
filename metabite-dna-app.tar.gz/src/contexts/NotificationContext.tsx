"use client";

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'achievement' | 'error';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  action?: {
    label: string;
    onClick: () => void;
  };
  persistent?: boolean;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  removeNotification: (id: string) => void;
  clearAllNotifications: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}

interface NotificationProviderProps {
  children: ReactNode;
  userId: string;
}

export function NotificationProvider({ children, userId }: NotificationProviderProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Load notifications from localStorage on mount
  useEffect(() => {
    const savedNotifications = localStorage.getItem(`notifications-${userId}`);
    if (savedNotifications) {
      try {
        const parsed = JSON.parse(savedNotifications);
        setNotifications(parsed);
      } catch (error) {
        console.error('Error loading notifications:', error);
      }
    }
  }, [userId]);

  // Save notifications to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(`notifications-${userId}`, JSON.stringify(notifications));
  }, [notifications, userId]);

  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `notification-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      read: false,
    };

    setNotifications(prev => [newNotification, ...prev]);

    // Auto-remove non-persistent notifications after 10 seconds
    if (!newNotification.persistent) {
      setTimeout(() => {
        setNotifications(prev => prev.filter(n => n.id !== newNotification.id));
      }, 10000);
    }

    // Show browser notification if permitted
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(newNotification.title, {
        body: newNotification.message,
        icon: '/favicon.ico'
      });
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const value: NotificationContextType = {
    notifications,
    unreadCount,
    addNotification,
    markAsRead,
    markAllAsRead,
    removeNotification,
    clearAllNotifications,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

// Hook for triggering common notifications
export function useNotificationTriggers() {
  const { addNotification } = useNotifications();

  const triggerMealLogged = (mealName: string, alignmentScore: number) => {
    addNotification({
      type: 'success',
      title: 'Meal Logged Successfully!',
      message: `${mealName} logged with ${alignmentScore}% DNA alignment.`,
      persistent: false,
    });
  };

  const triggerStreakMilestone = (streakType: string, days: number) => {
    addNotification({
      type: 'achievement',
      title: 'Streak Milestone! 🔥',
      message: `You've reached ${days} days of ${streakType}! Keep up the great work.`,
      persistent: true,
      action: {
        label: 'View Progress',
        onClick: () => console.log('View progress for', streakType),
      },
    });
  };

  const triggerLevelUp = (newLevel: number) => {
    addNotification({
      type: 'achievement',
      title: 'Level Up! 🎉',
      message: `Congratulations! You've reached Level ${newLevel} in your DNA nutrition journey.`,
      persistent: true,
      action: {
        label: 'Celebrate',
        onClick: () => console.log('Celebrate level', newLevel),
      },
    });
  };

  const triggerDNAAnalysisComplete = (profileId: string) => {
    addNotification({
      type: 'success',
      title: 'DNA Analysis Complete! 🧬',
      message: 'Your genetic profile has been processed. New insights are available!',
      persistent: true,
      action: {
        label: 'View Insights',
        onClick: () => console.log('View DNA insights for', profileId),
      },
    });
  };

  const triggerNutrientAlert = (nutrient: string, status: 'low' | 'high') => {
    addNotification({
      type: 'warning',
      title: 'Nutrient Balance Alert ⚠️',
      message: `Your ${nutrient} intake is ${status === 'low' ? 'below' : 'above'} optimal levels based on your DNA profile.`,
      persistent: true,
      action: {
        label: 'Get Recommendations',
        onClick: () => console.log('Get recommendations for', nutrient),
      },
    });
  };

  const triggerActivityReminder = () => {
    addNotification({
      type: 'info',
      title: 'Activity Reminder 🏃‍♂️',
      message: 'Time to get moving! Your DNA profile suggests regular activity for optimal health.',
      persistent: false,
    });
  };

  const triggerMealReminder = () => {
    addNotification({
      type: 'info',
      title: 'Meal Reminder 🍽️',
      message: 'Remember to log your meal to track your DNA-powered nutrition journey.',
      persistent: false,
    });
  };

  return {
    triggerMealLogged,
    triggerStreakMilestone,
    triggerLevelUp,
    triggerDNAAnalysisComplete,
    triggerNutrientAlert,
    triggerActivityReminder,
    triggerMealReminder,
  };
}